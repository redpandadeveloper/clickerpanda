// Глобальные переменные для изображений
let heartImg, bambooImg;
let clickWindowImg, bambooWindowImg;
let putInventImg, inventImg;
let bambooElementImg;
let heartFrameImg, heartIconImg;

let gameLogoImg; // Переменная для логотипа игры (redwork_logo.png)
let logobambooImg; // Переменная для логотипа Рыжика (LOGO RYZHIK.png)

let ryzhikSad;
let gameOverScreenImg;
let ryzhikMotivatorImg;
let pauseButtonImg;
let playButtonImg; // Кнопка "ИГРАТЬ" (используется и для паузы, и для старта)

let soundOnImg;
let soundOffImg;

let aboutImage; // Изображение для кнопок "Купить" и "Назад"
let languageImg; // Изображение для кнопки смены языка

let eatSound; // Звук поедания бамбука/яблока

// Игровые переменные
let hearts = []; // Массив для анимированных сердечек
let bamboos = []; // Массив для падающего бамбука
let clickCount = 0; // Клики за текущую игровую сессию
let totalClickCount = 0; // Общий счетчик кликов (для достижений)
let collectedBamboo = 0; // Собранный бамбук в инвентаре

let lives = 3; // Текущее количество жизней Рыжика
let maxLives = 3; // Максимальное количество жизней Рыжика

let inventoryOpen = false; // Флаг состояния инвентаря
let draggingBamboo = false; // Флаг перетаскивания бамбука
let dragX = 0; // X-координата для перетаскиваемого предмета (экранные координаты)
let dragY = 0; // Y-координата для перетаскиваемого предмета (экранные координаты)

let scaleFactor = 2.5; // Коэффициент масштабирования для холста
let bg, ryzhikIdle, ryzhikYawnStart, ryzhikYawnFull; // Изображения фона и анимаций Рыжика
let ryzhikMouthOpen; // Изображение Рыжика с открытым ртом
let currentImage; // Текущее изображение Рыжика
let yawnStage = 0; // Стадия зевка Рыжика
let lastYawnTime = 0; // Время последнего зевка

let feeding = false; // Флаг состояния кормления
let feedingStartTime = 0; // Время начала кормления
const feedingDelay = 2000; // Задержка для анимации кормления

let gameState = 'LOADING_SCREEN'; // Начальное состояние - экран загрузки

// Переменные для заставки
let splashStartTime = 0;
const SPLASH_FADE_IN_DURATION = 1000;
const SPLASH_HOLD_DURATION = 2000;
const SPLASH_FADE_OUT_DURATION = 1000;
const TOTAL_SPLASH_DURATION = SPLASH_FADE_IN_DURATION + SPLASH_HOLD_DURATION + SPLASH_FADE_OUT_DURATION;

// Скорость падения бамбука и логика ее изменения
let currentBaseBambooSpeed = 0.5; // Базовая скорость, которая увеличивается с кликами
const INITIAL_BAMBOO_FALL_SPEED = 0.5; // Первоначальная, самая медленная скорость для сброса (для замедлителя)
const clicksForSpeedIncrease = 50; // Сколько кликов нужно для увеличения скорости
const speedIncreaseAmount = 0.1; // На сколько увеличивается скорость
const maxBambooFallSpeed = 3.0; // Максимальная скорость падения бамбука
let speedIncreaseCounter = 0; // Счетчик для отслеживания увеличения скорости

// Переменные для механики мотиватора (Рыжик требует внимания)
let lastInteractionTime = 0; // Время последней интеракции с Рыжиком
let motivatorThreshold = 30000; // Порог бездействия для активации мотиватора (30 секунд)
const healthLossOnInactivity = 1; // Сколько жизней теряется при бездействии
let lastHealthLossTime = 0; // Время последней потери жизни (чтобы не было спама)

let motivatorActive = false; // Флаг активности мотиватора
let motivatorStartTime = 0; // Время активации мотиватора
const motivatorDuration = 5000; // Длительность состояния мотиватора (5 секунд)
let lifeLossPending = false; // Флаг, ожидается ли потеря жизни из-за мотиватора

// Переменные для паузы
let pauseStartTime = 0; // Время начала паузы
let elapsedPauseTime = 0; // Общее время, проведенное в паузе

// Переменные для музыки
let bgMusic; // Фоновая музыка
let musicStarted = false; // Флаг, начата ли музыка
let musicVolume = 0.5; // Громкость музыки
let isMusicOn = true; // Включена ли музыка

let shopButtonImg; // Изображение кнопки магазина

// Переменные для магазина: Дополнительные сердца
let activeExtraHearts = []; // Массив для отслеживания активных дополнительных сердец
const EXTRA_HEART_DURATION = 5 * 60 * 1000; // Длительность действия доп. сердца (10 минут)
const EXTRA_HEART_COST = 500; // Стоимость доп. сердца

// Переменные для магазина: Игрушка Рыжика
let toyBoostActive = false; // Флаг активности эффекта игрушки
let toyBoostStartTime = 0; // Время активации игрушки
const TOY_BOOST_DURATION = 10 * 60 * 1000; // Длительность действия игрушки (10 минут)
const TOY_COST = 1200; // Стоимость игрушки
const TOY_BOOST_VALUE = 60000; // Значение, на которое увеличивается motivatorThreshold (1 минута)

let maxLivesUpgradesCount = 0; // Количество купленных апгрейдов на жизни (для ПОСТОЯННЫХ апгрейдов, если они будут)
const MAX_MAX_LIVES_BUYS = 2; // Максимальное количество купленных апгрейдов на жизни

let toyUpgradesCount = 0; // Количество купленных игрушек
const MAX_TOY_BUYS = 1; // Максимальное количество купленных игрушек

// ====== НОВЫЕ ПЕРЕМЕННЫЕ ДЛЯ ЗАМЕДЛИТЕЛЯ БАМБУКА ======
let bambooSlowdownActive = false; // Флаг активности замедлителя
let bambooSlowdownStartTime = 0; // Время активации замедлителя
const BAMBOO_SLOWDOWN_DURATION = 60 * 1000; // 1 минута в миллисекундах
const BAMBOO_SLOWDOWN_COST = 800; // Стоимость замедлителя
// ======================================================

// ====== ДОБАВЛЕНИЯ ДЛЯ ЯБЛОК ======
let appleImg; // Изображение яблока
let apples = []; // Массив для падающих яблок
let appleElementImg; // Изображение яблока в инвентаре
let collectedApple = 0; // Собранные яблоки
let draggingApple = false; // Флаг перетаскивания яблока
const CLICKS_FOR_APPLE_DROP = 150; // Сколько кликов нужно для падения яблока
// ===================================

// ====== ДОБАВЛЕНИЯ ДЛЯ ДОСТИЖЕНИЙ ======
let achievementsButtonImg; // Изображение для кнопки достижений
let achievements = []; // Массив для хранения всех достижений

// Новые флаги для отслеживания условий достижений (БОЛЬШЕ НЕ СБРАСЫВАЮТСЯ В RESETGAME)
let firstYawnAchieved = false;
let firstFeedAchieved = false;
let fedOnLowHealthAchieved = false;
let lifeLostDuringGame = false;
let attendedToMotivatorAchieved = false;

// Переменные для скроллинга достижений
let scrollOffsetAchievements = 0; // Смещение скролла для экрана достижений
let maxScrollOffsetAchievements = 0; // Максимальное смещение скролла
const ACHIEVEMENT_ITEM_HEIGHT = 70; // Высота элемента достижения для расчета скролла

// Переменные для уведомлений о достижениях
let achievementsNotificationQueue = []; // Очередь уведомлений о достижениях
const NOTIFICATION_DURATION = 3000; // Общая длительность уведомления (появление + удержание + исчезания)
const NOTIFICATION_FADE_DURATION = 500; // Длительность фазы появления/исчезания

// Переменные для ограничения спавна сердечек (визуальный эффект клика)
let lastHeartSpawnTime = 0; // Время последнего спавна сердечка
const HEART_SPAWN_INTERVAL = 100; // Интервал в мс между появлением сердечек

// === ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ, СВЯЗАННЫЕ С SDK И ИГРОВЫМ ЦИКЛОМ ===
let ysdk = null;
let yandexPlayer = null; // Будет хранить объект Player
let yandexSDKInitialized = false; // Флаг инициализации SDK
let gameDataLoadedFlag = false; // Флаг, указывающий, что данные игры загружены (или сброшены, если нет сохранения)
let gameReadyToStart = false; // Новый флаг для отслеживания полной готовности игры
let saveTimer = null;
const SAVE_DELAY = 5000; // 5 секунд задержки для сохранения

// === ФЛАГ ДЛЯ ГОТОВНОСТИ ХРАНИЛИЩА (Теперь связан с yandexPlayer) ===
let playerDataAPIReady = false; // Этот флаг будет установлен в true, когда объект player будет доступен
// ===========================================

// === Переменные для отслеживания загрузки ассетов ===
let assetsToLoadCount = 27; // Убедитесь, что это количество соответствует всем загружаемым ассетам
let assetsLoadedCount = 0;
let allAssetsLoaded = false; // Флаг, указывающий, что все ассеты preload загружены
// =============================================================

// === НОВЫЕ ПЕРЕМЕННЫЕ ДЛЯ ВСПЛЫВАЮЩЕГО БОНУСА ===
let bonusNotifications = []; // Массив для всплывающих уведомлений о бонусах
const BONUS_NOTIFICATION_DURATION = 2000; // Длительность всплывающего бонуса (2 секунды)
const BONUS_NOTIFICATION_FADE_DURATION = 500; // Длительность фазы появления/исчезания бонуса (0.5 секунды)
// ===============================================

// Глобальная переменная для хранения объекта канваса p5.js
let myCanvas; // <<< ПЕРЕМЕННАЯ ДЛЯ НАДЕЖНОЙ ССЫЛКИ НА КАНВАС

// Объект с переводами всех текстовых строк
let currentLanguage = 'ru'; // Текущий язык, по умолчанию русский
const translations = {
    ru: {
        loading_resources: "Загрузка ресурсов игры...",
        initializing_sdk: "Инициализация Яндекс SDK...",
        loading_game_data: "Загрузка игровых данных...",
        clickerpanda_title: "ClickerPanda",
        play_button: "ИГРАТЬ",
        bag_of_bamboo: "Мешок с бамбуком",
        bamboo_count: "Бамбук: ",
        apples_count: "Яблоки: ",
        exit_inventory_tip: "Нажми на мешок, чтобы выйти",
        pause_title: "ПАУЗА",
        continue_game_tip: "Нажми кнопку, чтобы продолжить",
        achievements_button: "Достижения",
        shop_title: "МАГАЗИН",
        your_clicks: "Ваши клики: ",
        extra_heart: "Доп. сердце",
        cost: "Стоимость: ",
        clicks_short: " кл.",
        active: "Активно: ",
        until_seconds: " до ",
        seconds_short: " сек",
        minutes_short: " мин",
        max_bought: "Макс. куплено", // Этот текст будет использоваться для постоянных улучшений
        buy_button: "КУПИТЬ",
        toy: "Игрушка",
        bamboo_slowdown: "Медленный бамбук",
        bamboo_slowdown_active: "Активно",
        back_button: "НАЗАД",
        game_over_tip_header: "НЕБОЛЬШОЙ СОВЕТ:",
        game_over_tip_line1: "Перетаскивай иконку бамбука на Рыжика,",
        game_over_tip_line2: "чтобы восстановить сердца.",
        game_over_tip_line3: "Красные панды большую часть жизни едят бамбук",
        game_over_tip_line4: "- как основной источник энергии!",
        game_over_start_new_game: "Начать новую игру", 
        achievements_screen_title: "ДОСТИЖЕНИЯ",
        achievement_header: "ДОСТИЖЕНИЕ:",
        not_enough_clicks_heart: "Недостаточно кликов для сердца!",
        not_enough_clicks_toy: "Недостаточно кликов для игрушки!",
        not_enough_clicks_slowdown: "Недостаточно кликов для замедлителя!",
        no_bamboo_in_inventory: "Нет бамбука в инвентаре!",
        no_apples_in_inventory: "Нет яблок в инвентаре!",
        slowdown: "Замедление", 
        
        // Новые тексты для магазина
        already_active: "Уже активно",

        // Достижения
        ach_clicks_1M_name: 'ЧЕМПИОН ClickPanda!',
        ach_clicks_1M_desc: 'Собрать 1.000.000 кликов!',
        ach_apples_100_name: 'Яблочный гурман!',
        ach_apples_100_desc: 'Собрать 100 яблок.',
        ach_first_apple_name: 'Яблоко,- скажи где Рыжя?',
        ach_first_apple_desc: 'Собрать редкий фрукт среди бамбука (первое яблоко).',
        ach_first_yawn_name: 'Широкий зевок',
        ach_first_yawn_desc: 'Разблокируй первый зевок панды, просто играя в игру!',
        ach_first_feed_name: 'Бамбуковое счастье!',
        ach_first_feed_desc: 'Впервые накорми Рыжика.',
        ach_bamboo_100_keeper_name: 'Заботливый зоокипер',
        ach_bamboo_100_keeper_desc: 'Собери 100 кусочков бамбука.',
        ach_bamboo_1000_name: 'Лес сладостей',
        ach_bamboo_1000_desc: 'Собеби 1000 кусочков бамбука.',
        ach_fed_low_health_name: 'На грани исчезновения...',
        ach_fed_low_health_desc: 'Остаться с последним сердечком и накормить Рыжика.',
        ach_long_life_name: 'Долгожитель',
        ach_long_life_desc: 'Набрать 10.000 кликов не потеряв ни одного сердечка.',
        ach_bought_extra_heart_name: 'Защитник',
        ach_bought_extra_heart_desc: 'Приобрести +1 сердце на время!',
        ach_bamboo_100_ambassador_name: 'Лесной амбассадор!',
        ach_bamboo_100_ambassador_desc: 'Собрать 100 бамбука.',
        ach_attended_motivator_name: 'Настоящая забота',
        ach_attended_motivator_desc: 'Обратить внимание на Рыжика.',
        ach_bamboo_1M_name: 'ЧТО! Невозможно!',
        ach_bamboo_1M_desc: 'Собрать 1.000.000 бамбука.',
    },
    en: {
        loading_resources: "Loading game resources...",
        initializing_sdk: "Initializing Yandex SDK...",
        loading_game_data: "Loading game data...",
        clickerpanda_title: "ClickerPanda",
        play_button: "PLAY",
        bag_of_bamboo: "Bag of Bamboo",
        bamboo_count: "Bamboo: ",
        apples_count: "Apples: ",
        exit_inventory_tip: "Tap the bag to exit",
        pause_title: "PAUSE",
        continue_game_tip: "Tap the button to continue",
        achievements_button: "Achievements",
        shop_title: "SHOP",
        your_clicks: "Your Clicks: ",
        extra_heart: "Extra Heart",
        cost: "Cost: ",
        clicks_short: " cl.",
        active: "Active: ",
        until_seconds: " for ",
        seconds_short: " sec",
        minutes_short: " min",
        max_bought: "Max bought", 
        buy_button: "BUY",
        toy: "Toy",
        bamboo_slowdown: "Bamboo Slowdown",
        bamboo_slowdown_active: "Active",
        back_button: "BACK",
        game_over_tip_header: "SMALL TIP:",
        game_over_tip_line1: "Drag the bamboo icon to Ryzhik,",
        game_over_tip_line2: "to restore hearts.",
        game_over_tip_line3: "Red pandas eat bamboo most of their lives",
        game_over_tip_line4: "- as their main energy source!",
        game_over_start_new_game: "Start New Game", 
        achievements_screen_title: "ACHIEVEMENTS",
        achievement_header: "ACHIEVEMENT:",
        not_enough_clicks_heart: "Not enough clicks for heart!",
        not_enough_clicks_toy: "Not enough clicks for toy!",
        not_enough_clicks_slowdown: "Not enough clicks for slowdown!",
        no_bamboo_in_inventory: "No bamboo in inventory!",
        no_apples_in_inventory: "No apples in inventory!",
        slowdown: "Slowdown",

        // New shop texts
        already_active: "Already active",

        // Achievements
        ach_clicks_1M_name: 'ClickPanda Champion!',
        ach_clicks_1M_desc: 'Collect 1,000,000 clicks!',
        ach_apples_100_name: 'Apple Gourmet!',
        ach_apples_100_desc: 'Collect 100 apples.',
        ach_first_apple_name: 'Apple, where\'s Ryzhik?',
        ach_first_apple_desc: 'Collect a rare fruit among bamboo (first apple).',
        ach_first_yawn_name: 'Wide Yawn',
        ach_first_yawn_desc: 'Unlock the first panda yawn just by playing the game!',
        ach_first_feed_name: 'Bamboo Happiness!',
        ach_first_feed_desc: 'Feed Ryzhik for the first time.',
        ach_bamboo_100_keeper_name: 'Caring Zookeeper',
        ach_bamboo_100_keeper_desc: 'Collect 100 pieces of bamboo.',
        ach_bamboo_1000_name: 'Forest of Sweets',
        ach_bamboo_1000_desc: 'Collect 1000 pieces of bamboo.',
        ach_fed_low_health_name: 'On the Brink of Extinction...',
        ach_fed_low_health_desc: 'Stay on the last heart and feed Ryzhik.',
        ach_long_life_name: 'Long Liver',
        ach_long_life_desc: 'Reach 10,000 clicks without losing a single heart.',
        ach_bought_extra_heart_name: 'Protector',
        ach_bought_extra_heart_desc: 'Purchase +1 heart for a limited time!',
        ach_bamboo_100_ambassador_name: 'Forest Ambassador!',
        ach_bamboo_100_ambassador_desc: 'Collect 100 bamboo.',
        ach_attended_motivator_name: 'True Care',
        ach_attended_motivator_desc: 'Pay attention to Ryzhik.',
        ach_bamboo_1M_name: 'WHAT! Impossible!',
        ach_bamboo_1M_desc: 'Collect 1,000,000 bamboo.',
    }
};

// Определение достижений
function initializeAchievements() {
    achievements = [
        {
            id: 'clicks_1M',
            name_key: 'ach_clicks_1M_name', // Используем ключ для локализации
            description_key: 'ach_clicks_1M_desc', // Используем ключ для локализации
            condition: () => totalClickCount >= 1000000,
            completed: false
        },
        {
            id: 'apples_100',
            name_key: 'ach_apples_100_name',
            description_key: 'ach_apples_100_desc',
            condition: () => collectedApple >= 100,
            completed: false
        },
        {
            id: 'first_apple',
            name_key: 'ach_first_apple_name',
            description_key: 'ach_first_apple_desc',
            condition: () => collectedApple >= 1,
            completed: false
        },
        {
            id: 'first_yawn',
            name_key: 'ach_first_yawn_name',
            description_key: 'ach_first_yawn_desc',
            condition: () => firstYawnAchieved,
            completed: false
        },
        {
            id: 'first_feed',
            name_key: 'ach_first_feed_name',
            description_key: 'ach_first_feed_desc',
            condition: () => firstFeedAchieved,
            completed: false
        },
        {
            id: 'bamboo_100_keeper',
            name_key: 'ach_bamboo_100_keeper_name',
            description_key: 'ach_bamboo_100_keeper_desc',
            condition: () => collectedBamboo >= 100,
            completed: false
        },
        {
            id: 'bamboo_1000',
            name_key: 'ach_bamboo_1000_name',
            description_key: 'ach_bamboo_1000_desc',
            condition: () => collectedBamboo >= 1000,
            completed: false
        },
        {
            id: 'fed_low_health',
            name_key: 'ach_fed_low_health_name',
            description_key: 'ach_fed_low_health_desc',
            condition: () => fedOnLowHealthAchieved,
            completed: false
        },
        {
            id: 'long_life',
            name_key: 'ach_long_life_name',
            description_key: 'ach_long_life_desc',
            condition: () => totalClickCount >= 10000 && !lifeLostDuringGame,
            completed: false
        },
        {
            id: 'bought_extra_heart',
            name_key: 'ach_bought_extra_heart_name',
            description_key: 'ach_bought_extra_heart_desc',
            condition: () => maxLivesUpgradesCount >= 1, // Достижение для permanent maxLivesUpgradesCount
            completed: false
        },
        {
            id: 'bamboo_100_ambassador',
            name_key: 'ach_bamboo_100_ambassador_name',
            description_key: 'ach_bamboo_100_ambassador_desc',
            condition: () => collectedBamboo >= 100,
            completed: false
        },
        {
            id: 'attended_motivator',
            name_key: 'ach_attended_motivator_name',
            description_key: 'ach_attended_motivator_desc',
            condition: () => attendedToMotivatorAchieved,
            completed: false
        },
        {
            id: 'bamboo_1M',
            name_key: 'ach_bamboo_1M_name',
            description_key: 'ach_bamboo_1M_desc',
            condition: () => collectedBamboo >= 1000000,
            completed: false
        }
    ];
}

// Функция для получения переведенной строки
function getTranslation(key) {
    return translations[currentLanguage][key] || key; // Возвращаем ключ, если перевод не найден
}

// Функция для проверки и обновления статуса достижений
function checkAchievements() {
    achievements.forEach(achievement => {
        if (!achievement.completed && achievement.condition()) {
            achievement.completed = true;
            achievementsNotificationQueue.push({
                messageHeader: getTranslation('achievement_header'),
                messageText: getTranslation(achievement.name_key),
                startTime: millis()
            });
            saveGameData(true); 
        }
    });
}

// =========================================================================
// === Yandex SDK ИНТЕГРАЦИЯ И ФУНКЦИИ СОХРАНЕНИЯ/ЗАГРУЗКИ (ОБНОВЛЕНО) ===
// === Теперь используется yandexPlayer.setData() / .getData() ===
// =========================================================================

/**
 * Вспомогательная функция для ожидания готовности объекта Player.
 * yandexPlayer и его методы (setData, getData) должны быть доступны.
 * @returns {Promise<void>} Промис, который разрешится, когда yandexPlayer будет доступен, или отклонится по таймауту.
 */
function waitForPlayerReady() {
    return new Promise((resolve, reject) => {
        const checkInterval = 100; // Проверять каждые 100 мс
        const timeout = 5000; // Таймаут 5 секунд
        const startTime = Date.now();

        console.log("waitForPlayerReady: Начинаем опрос готовности объекта Player...");

        const check = () => {
            // Проверяем, что yandexPlayer существует и у него есть метод setData (для уверенности в готовности)
            if (yandexPlayer && typeof yandexPlayer.setData === 'function') {
                console.log("waitForPlayerReady: Объект Player доступен и готов.");
                playerDataAPIReady = true; // Устанавливаем глобальный флаг
                resolve();
            } else if (Date.now() - startTime > timeout) {
                console.error("waitForPlayerReady: Таймаут ожидания готовности объекта Player.");
                playerDataAPIReady = false; // Убедимся, что флаг выключен
                reject(new Error("Player API readiness timeout"));
            } else {
                // console.log("waitForPlayerReady: Объект Player еще не готов. Повторная проверка...");
                setTimeout(check, checkInterval);
            }
        };
        check();
    });
}


// НОВАЯ ФУНКЦИЯ: Основная точка входа для инициализации игры после загрузки SDK
// Эта функция вызывается из index.html после инициализации YaGames SDK
async function initGameWithSDK(sdk) { 
    ysdk = sdk; // Присваиваем глобальный объект SDK
    yandexSDKInitialized = !!sdk; // Флаг будет true, если sdk не null

    if (yandexSDKInitialized) {
        console.log("SDK is ready in initGameWithSDK.");
        
        // Автоматическое определение языка через SDK
        const sdkLang = ysdk.environment.i18n.lang;
        if (translations[sdkLang]) {
            currentLanguage = sdkLang;
            console.log("Language set from Yandex SDK:", currentLanguage);
        } else {
            console.warn("Yandex SDK language not supported, defaulting to Russian:", sdkLang);
            currentLanguage = 'ru'; // По умолчанию русский, если язык SDK не поддерживается
        }

        try {
            // Сначала получаем объект Player
            await ysdk.getPlayer()
                .then(player => {
                    yandexPlayer = player;
                    console.log("Yandex Player loaded:", yandexPlayer);
                })
                .catch(err => {
                    console.warn("Failed to get Yandex Player. This might happen for anonymous users or other issues:", err);
                    // Если не удалось получить Player, но SDK инициализировался, продолжаем без него,
                    // но сохранение не будет работать.
                    yandexPlayer = null; 
                });
            
            // Затем ждем, пока объект Player будет гарантированно готов для операций
            // Только если yandexPlayer был успешно получен
            if (yandexPlayer) {
                await waitForPlayerReady(); 
            } else {
                console.warn("Player object not available. Skipping waitForPlayerReady. Player data API will be unavailable.");
                playerDataAPIReady = false; // Убедимся, что флаг выключен
            }
            
            loadGameData(); // Загружаем данные только после попытки получить игрока и дождаться его готовности
        } catch (err) {
            console.error("Failed to initialize Yandex SDK Player (after polling). Proceeding without Player data API.", err);
            playerDataAPIReady = false; // Убедимся, что флаг выключен при любой ошибке
            gameDataLoadedFlag = true; 
            checkGameReadyConditions();
            // Запускаем resetGame, чтобы игра запустилась, если что-то пошло не так с SDK
            resetGame(); 
        }

        // Слушатели событий паузы/возобновления игры от SDK
        window.addEventListener('beforeunload', () => {
            console.log("EVENT: beforeunload. Attempting to save game data.");
            saveGameData(true); // Принудительное сохранение перед закрытием/перезагрузкой
        });

        ysdk.on('game_api_pause', () => {
            console.log("SDK EVENT: game_api_pause received. Pausing music and saving game.");
            if (bgMusic && bgMusic.isPlaying()) {
                bgMusic.pause();
                console.log("Music paused.");
            }
            saveGameData(true); // Сохраняем состояние при паузе
        });
        ysdk.on('game_api_resume', () => {
            console.log("SDK EVENT: game_api_resume received. Resuming music if enabled.");
            if (bgMusic && isMusicOn && bgMusic.isPaused()) {
                bgMusic.play();
                console.log("Music resumed.");
            }
        });
    } else {
        console.warn("SDK not available in initGameWithSDK. Proceeding without SDK features.");
        playerDataAPIReady = false; // Если SDK вообще нет, хранилище не готово
        loadGameData(); // Загружаем данные (или начинаем новую игру), даже если SDK недоступен
    }
}

// Функция для сохранения игровых данных с отложенным вызовом (debounce)
function saveGameData(forceSave = false) {
    // Проверяем наш новый глобальный флаг playerDataAPIReady и наличие yandexPlayer
    if (!playerDataAPIReady || !yandexPlayer || typeof yandexPlayer.setData !== 'function') {
        console.warn("Yandex Player Data API is not ready for saving. Cannot save data.");
        return;
    }

    if (saveTimer) {
        clearTimeout(saveTimer);
    }

    if (forceSave) {
        performSave();
    } else {
        saveTimer = setTimeout(performSave, SAVE_DELAY);
    }
}

// Непосредственно функция сохранения
function performSave() {
    console.log("Performing save to Yandex Player Data...");

    const now = millis();
    const gameTime = now - elapsedPauseTime;

    const activeHeartsToSave = activeExtraHearts.map(h => {
        const remaining = (h.startTime + EXTRA_HEART_DURATION) - gameTime;
        return { remainingDuration: remaining > 0 ? remaining : 0 };
    }).filter(h => h.remainingDuration > 0);

    let toyRemainingDuration = 0;
    if (toyBoostActive) {
        toyRemainingDuration = (toyBoostStartTime + TOY_BOOST_DURATION) - gameTime;
        if (toyRemainingDuration < 0) toyRemainingDuration = 0;
    }

    let bambooSlowdownRemainingDuration = 0;
    if (bambooSlowdownActive) {
        bambooSlowdownRemainingDuration = (bambooSlowdownStartTime + BAMBOO_SLOWDOWN_DURATION) - gameTime;
        if (bambooSlowdownRemainingDuration < 0) bambooSlowdownRemainingDuration = 0;
    }

    // Собираем все данные, которые нужно сохранить
    const dataToSave = {
        clickCount: clickCount, 
        totalClickCount: totalClickCount,
        collectedBamboo: collectedBamboo,
        collectedApple: collectedApple,
        lives: lives,
        maxLivesUpgradesCount: maxLivesUpgradesCount, // Сохраняем для потенциальных постоянных апгрейдов
        toyUpgradesCount: toyUpgradesCount,
        
        activeHeartsToSave: activeHeartsToSave, 
        toyBoostActive: toyBoostActive,
        toyBoostRemainingDuration: toyRemainingDuration,
        bambooSlowdownActive: bambooSlowdownActive,
        bambooSlowdownRemainingDuration: bambooSlowdownRemainingDuration,

        achievements: achievements.map(ach => ({
            id: ach.id,
            completed: ach.completed
        })),
        firstYawnAchieved: firstYawnAchieved,
        firstFeedAchieved: firstFeedAchieved,
        fedOnLowHealthAchieved: fedOnLowHealthAchieved,
        lifeLostDuringGame: lifeLostDuringGame,
        attendedToMotivatorAchieved: attendedToMotivatorAchieved,

        currentBaseBambooSpeed: currentBaseBambooSpeed, 
        speedIncreaseCounter: speedIncreaseCounter,       

        isMusicOn: isMusicOn,
        musicVolume: musicVolume,
        currentLanguage: currentLanguage
    };

    console.log("Данные для сохранения (через player.setData):", dataToSave);

    // Используем yandexPlayer.setData()
    yandexPlayer.setData(dataToSave)
        .then(() => {
            console.log("Игровые данные успешно сохранены через player.setData!");
        })
        .catch(err => {
            console.warn("Не удалось сохранить игровые данные через player.setData:", err);
        });
}

// Функция для загрузки игровых данных
function loadGameData() {
    // Проверяем наш новый глобальный флаг playerDataAPIReady и наличие yandexPlayer
    if (!playerDataAPIReady || !yandexPlayer || typeof yandexPlayer.getData !== 'function') {
        console.warn("Yandex Player Data API is not ready for loading. Cannot load data. Starting new game.");
        resetGame(); 
        gameDataLoadedFlag = true; 
        checkGameReadyConditions(); 
        return;
    }

    console.log("Попытка загрузить игровые данные из хранилища (через player.getData)...");

    // Используем yandexPlayer.getData()
    yandexPlayer.getData()
        .then(data => {
            if (data) {
                console.log("Игровые данные успешно загружены (исходные, через player.getData):", data);
                const now = millis();

                clickCount = data.clickCount !== undefined ? data.clickCount : 0;
                totalClickCount = data.totalClickCount !== undefined ? data.totalClickCount : 0;
                collectedBamboo = data.collectedBamboo !== undefined ? data.collectedBamboo : 0;
                collectedApple = data.collectedApple !== undefined ? data.collectedApple : 0;
                lives = data.lives !== undefined ? data.lives : 3;
                maxLivesUpgradesCount = data.maxLivesUpgradesCount !== undefined ? data.maxLivesUpgradesCount : 0;
                toyUpgradesCount = data.toyUpgradesCount !== undefined ? data.toyUpgradesCount : 0;

                activeExtraHearts = [];
                if (data.activeHeartsToSave && Array.isArray(data.activeHeartsToSave)) { 
                    data.activeHeartsToSave.forEach(h => {
                        if (h.remainingDuration > 0) {
                            activeExtraHearts.push({
                                startTime: now - (EXTRA_HEART_DURATION - h.remainingDuration)
                            });
                        }
                    });
                }
                // maxLives пересчитывается в draw() постоянно, чтобы учесть изменения activeExtraHearts
                maxLives = 3 + (maxLivesUpgradesCount * 1) + activeExtraHearts.length; 
                lives = constrain(lives, 0, maxLives); 


                toyBoostActive = data.toyBoostActive !== undefined ? data.toyBoostActive : false;
                if (toyBoostActive && data.toyBoostRemainingDuration > 0) {
                    toyBoostStartTime = now - (TOY_BOOST_DURATION - data.toyBoostRemainingDuration);
                } else {
                    toyBoostActive = false;
                    toyBoostStartTime = 0;
                }
                motivatorThreshold = toyBoostActive ? (30000 + TOY_BOOST_VALUE) : 30000;

                bambooSlowdownActive = data.bambooSlowdownActive !== undefined ? data.bambooSlowdownActive : false;
                if (bambooSlowdownActive && data.bambooSlowdownRemainingDuration > 0) {
                    bambooSlowdownStartTime = now - (BAMBOO_SLOWDOWN_DURATION - data.bambooSlowdownRemainingDuration);
                } else {
                    bambooSlowdownActive = false;
                    bambooSlowdownStartTime = 0;
                }

                currentBaseBambooSpeed = data.currentBaseBambooSpeed !== undefined ? data.currentBaseBambooSpeed : INITIAL_BAMBOO_FALL_SPEED;
                speedIncreaseCounter = data.speedIncreaseCounter !== undefined ? data.speedIncreaseCounter : 0;

                initializeAchievements(); 
                if (data.achievements && Array.isArray(data.achievements)) {
                    data.achievements.forEach(savedAch => {
                        const ach = achievements.find(a => a.id === savedAch.id);
                        if (ach) {
                            ach.completed = savedAch.completed; 
                        }
                    });
                }
                firstYawnAchieved = data.firstYawnAchieved !== undefined ? data.firstYawnAchieved : false;
                firstFeedAchieved = data.firstFeedAchieved !== undefined ? data.firstFeedAchieved : false;
                fedOnLowHealthAchieved = data.fedOnLowHealthAchieved !== undefined ? data.fedOnLowHealthAchieved : false;
                lifeLostDuringGame = false; 
                attendedToMotivatorAchieved = data.attendedToMotivatorAchieved !== undefined ? data.attendedToMotivatorAchieved : false;


                isMusicOn = data.isMusicOn !== undefined ? data.isMusicOn : true;
                musicVolume = data.musicVolume !== undefined ? data.musicVolume : 0.5;
                if (bgMusic) {
                    bgMusic.setVolume(isMusicOn ? musicVolume : 0);
                    // Дополнительный лог при загрузке данных
                    console.log(`Music loaded: isMusicOn=${isMusicOn}, volume=${musicVolume}`);
                }

                if (data.currentLanguage && translations[data.currentLanguage]) {
                    currentLanguage = data.currentLanguage;
                } else {
                    if (ysdk && ysdk.environment && ysdk.environment.i18n && ysdk.environment.i18n.lang && translations[ysdk.environment.i18n.lang]) {
                         currentLanguage = ysdk.environment.i18n.lang;
                    } else {
                         currentLanguage = 'ru';
                    }
                }

                lastInteractionTime = now; 
                lastYawnTime = now;       
                lastHealthLossTime = now; 
                elapsedPauseTime = 0;     
                motivatorActive = false;  
                lifeLossPending = false;  
                yawnStage = 0;            
                currentImage = ryzhikIdle; 

                console.log("Состояние игры после загрузки:", {
                    clickCount, totalClickCount, collectedBamboo, collectedApple, lives, maxLives,
                    activeExtraHearts, toyBoostActive, bambooSlowdownActive,
                    currentBaseBambooSpeed, speedIncreaseCounter,
                    firstYawnAchieved, firstFeedAchieved, fedOnLowHealthAchieved, lifeLostDuringGame, attendedToMotivatorAchieved,
                    isMusicOn, musicVolume, currentLanguage,
                    lastInteractionTime, lastYawnTime, lastHealthLossTime
                });

            } else {
                console.log("Сохраненных игровых данных не найдено. Запуск новой игры.");
                resetGame(); 
            }
            gameDataLoadedFlag = true; 
            checkGameReadyConditions(); 
        })
        .catch(err => {
            console.warn("Не удалось загрузить игровые данные через player.getData:", err);
            resetGame(); 
            gameDataLoadedFlag = true;
            checkGameReadyConditions();
        });
}

// Функция для показа полноэкранной (интерстициальной) рекламы
function showFullscreenAd() {
    if (ysdk && ysdk.adv) {
        console.log("Попытка показа полноэкранной рекламы...");
        ysdk.adv.showFullscreenAdv({
            onOpen: () => {
                console.log('Полноэкранная реклама открыта.');
                if (bgMusic && bgMusic.isPlaying()) {
                    bgMusic.pause();
                    console.log("Music paused for ad.");
                }
            },
            onClose: () => {
                console.log('Полноэкранная реклама закрыта.');
                if (bgMusic && isMusicOn && bgMusic.isPaused()) {
                    bgMusic.play();
                    console.log("Music resumed after ad.");
                }
            },
            onError: (err) => {
                console.warn('Ошибка при показе полноэкранной рекламы:', err);
                if (bgMusic && isMusicOn && bgMusic.isPaused()) {
                    bgMusic.play();
                    console.log("Music resumed after ad error.");
                }
            }
        });
    } else {
        console.warn("Yandex SDK Advertising API не готов или не поддерживается. Реклама не показана.");
    }
}

// Функция для запроса полноэкранного режима игры
function requestFullscreenGame() {
    if (ysdk && ysdk.features && ysdk.features.Fullscreen) {
        console.log("Полноэкранный режим успешно запрошен.");
        ysdk.features.Fullscreen.requestFullscreen()
            .then(() => {
                console.log("Полноэкранный режим успешно активирован.");
            })
            .catch(err => {
                console.warn("Не удалось запросить полноэкранный режим:", err);
            });
    } else {
        console.warn("Yandex SDK Fullscreen API не готов. Попытка использования нативного API браузера.");
        if (document.documentElement.requestFullscreen) {
            document.documentElement.requestFullscreen();
        } else if (document.documentElement.mozRequestFullScreen) {
            document.documentElement.mozRequestFullScreen();
        } else if (document.documentElement.webkitRequestFullscreen) {
            document.documentElement.webkitRequestFullscreen();
        } else if (document.documentElement.msRequestFullscreen) {
            document.documentElement.msRequestFullscreen();
        } else {
            console.warn("Полноэкранный режим не поддерживается вашим браузером.");
        }
    }
}

// =========================================================================
// === КОНЕЦ БЛОКА Yandex SDK ИНТЕГРАЦИИ ===
// =========================================================================


// Новая функция для проверки условий готовности игры и запуска
function checkGameReadyConditions() {
    console.log("Checking game ready conditions:", { allAssetsLoaded, yandexSDKInitialized, gameDataLoadedFlag });
    if (allAssetsLoaded && yandexSDKInitialized && gameDataLoadedFlag && !gameReadyToStart) {
        console.log("All readiness conditions met. Preparing to start game.");
        gameReadyToStart = true; // Устанавливаем флаг, что игра готова
        gameState = 'SPLASH_SCREEN';
        splashStartTime = millis();

        // Вызываем LoadingAPI.ready() только здесь, когда все действительно готово
        if (ysdk && ysdk.features && ysdk.features.LoadingAPI) {
            ysdk.features.LoadingAPI.ready();
            console.log("LoadingAPI.ready() called from checkGameReadyConditions.");
        } else {
             console.warn("LoadingAPI недоступен при вызове ready().");
        }
    }
}

// Function to track asset loading progress
function assetLoaded() {
    assetsLoadedCount++;
    console.log(`Asset loaded: ${assetsLoadedCount}/${assetsToLoadCount}`);
    if (assetsLoadedCount === assetsToLoadCount) {
        allAssetsLoaded = true;
        console.log("All game assets (via custom counter) loaded.");
        checkGameReadyConditions(); // Проверить условия готовности после загрузки ассетов
    }
}

// Function to handle asset loading errors
function assetLoadError(err, assetName) {
    console.error(`Failed to load asset: ${assetName}`, err);
    assetLoaded(); // Call assetLoaded even on error to unblock the process
}

// Функция для пересчета максимального смещения скролла достижений
function calculateMaxScrollOffsetAchievements(count) {
    let targetDisplayHeight = height / scaleFactor;
    let displayAreaY = 50; 
    let backButtonHeight = 30; 
    let tempBackButtonY = targetDisplayHeight - 50; 
    let backButtonTopEdgeY = tempBackButtonY - (backButtonHeight / 2); 
    let paddingAboveButton = 15; 
    let clippedAreaBottomY = backButtonTopEdgeY - paddingAreaY;
    let displayAreaHeight = clippedAreaBottomY - displayAreaY;
    
    let totalContentHeight = count * ACHIEVEMENT_ITEM_HEIGHT;
    maxScrollOffsetAchievements = max(0, totalContentHeight - displayAreaHeight);
}


function preload() {
    console.log("preload() called. Starting asset loading...");

    // Убедитесь, что это количество соответствует всем загружаемым ассетам
    // assetsToLoadCount = 27; // Установлено в глобальных переменных

    function safeLoadSound(path) {
        return loadSound(path, () => assetLoaded(), (err) => assetLoadError(err, path));
    }
    function safeLoadImage(path) {
        return loadImage(path, () => assetLoaded(), (err) => assetLoadError(err, path));
    }

    bgMusic = safeLoadSound('music.mp3');
    eatSound = safeLoadSound('bamboo_sound.mp3');

    bg = safeLoadImage("bg_forest.png");
    ryzhikIdle = safeLoadImage("ryzhik_idle.png");
    ryzhikYawnStart = safeLoadImage("ryzhik_yawn_start.png");
    ryzhikYawnFull = safeLoadImage("ryzhik_yawn_full.png");
    ryzhikMouthOpen = safeLoadImage("ryzhikMouthOpen.png");
    ryzhikSad = safeLoadImage("ryzhik_sad.png");
    gameOverScreenImg = safeLoadImage("game_over_screen.png");
    ryzhikMotivatorImg = safeLoadImage("ryzhik_motivator.png");
    heartImg = safeLoadImage("heart.png");
    bambooImg = safeLoadImage("bamboo.png");
    
    appleImg = safeLoadImage("apple.png");
    appleElementImg = safeLoadImage("apple_element.png");

    clickWindowImg = safeLoadImage("click_window.png");
    bambooWindowImg = safeLoadImage("click_window_2.png");
    putInventImg = safeLoadImage("put_invent.png");
    inventImg = safeLoadImage("invent.png");
    bambooElementImg = safeLoadImage("bamboo_element.png");

    heartFrameImg = safeLoadImage('heart_ramka.png');
    heartIconImg = safeLoadImage('heart_icon.png');
    pauseButtonImg = safeLoadImage('stop_game.png');
    playButtonImg = safeLoadImage('tap_play.png');

    shopButtonImg = safeLoadImage("shop_button.png");

    soundOnImg = safeLoadImage('put_on.png');
    soundOffImg = safeLoadImage('put_off.png');
    aboutImage = safeLoadImage('about.png');
    languageImg = safeLoadImage('language.png'); 

    gameLogoImg = safeLoadImage('redwork_logo.png');
    logobambooImg = safeLoadImage("logo_ryzhik.png");
    
    achievementsButtonImg = safeLoadImage('achievements_button.png'); 
    loadgameoverImg = safeLoadImage('game_over_button_menu.png'); 
  
}

// p5.js функция, вызываемая после успешной загрузки всех ассетов из preload
function setup() {

  document.body.style.background = "url('picture.png') no-repeat center center";
  document.body.style.backgroundSize = "cover";
  document.body.style.margin = "0";
  document.body.style.overflow = "hidden";

    console.log("setup() called. Creating canvas...");
    myCanvas = createCanvas(200 * scaleFactor, 400 * scaleFactor); // <<< ПРИСВАИВАЕМ ОБЪЕКТ КАНВАСА ГЛОБАЛЬНОЙ ПЕРЕМЕННОЙ
    noSmooth();
    imageMode(CENTER);
    textAlign(CENTER, CENTER);
    textSize(24);
    fill(255);
    stroke(0);
    strokeWeight(3);

    if (ryzhikIdle && ryzhikIdle.width > 0) {
        currentImage = ryzhikIdle; 
    } else {
        console.warn("ryzhikIdle image not loaded in setup. Using a fallback or blank.");
        currentImage = undefined;
    }

    maxLives = 3;
    motivatorThreshold = 30000;
    lives = maxLives;
    isMusicOn = true;
    musicVolume = 0.5;
    
    initializeAchievements();

    if (bgMusic) {
        bgMusic.setVolume(isMusicOn ? musicVolume : 0);
        console.log(`Initial music volume set: ${isMusicOn ? musicVolume : 0}`);
    }

    // --- Исправление: Отключение контекстного меню ---
    // Отключаем стандартное контекстное меню при правом клике на канвасе
    if (myCanvas && myCanvas.elt) { 
        myCanvas.elt.addEventListener('contextmenu', function(e) {
            e.preventDefault(); // Отменяем стандартное действие браузера
        });
    } else {
        console.warn("myCanvas or myCanvas.elt is not available in setup for contextmenu listener.");
    }
    // Стили user-select: none перенесены в CSS (index.html), как более надежное решение.

    console.log("p5.js setup complete.");
}

function draw() {
    scale(scaleFactor); 

    let targetDisplayWidth = width / scaleFactor; 
    let targetDisplayHeight = height / scaleFactor; 

    if (!gameReadyToStart) {
        background(0);
        fill(255);
        textSize(20);
        textAlign(CENTER, CENTER);

        let loadingMessage = getTranslation('loading_resources');
        if (allAssetsLoaded && !yandexSDKInitialized) {
            loadingMessage = getTranslation('initializing_sdk');
        } else if (allAssetsLoaded && yandexSDKInitialized && !gameDataLoadedFlag) {
            loadingMessage = getTranslation('loading_game_data');
        }
        
        text(loadingMessage, targetDisplayWidth / 2, targetDisplayHeight / 2);

        let dotCount = floor((millis() % 1000) / 250) + 1;
        text(".".repeat(dotCount), targetDisplayWidth / 2 + textWidth(loadingMessage)/2 + 5, targetDisplayHeight / 2);

        return;
    }
    
    let offsetX = map(mouseX / scaleFactor, 0, targetDisplayWidth, -5, 5); 
    let offsetY = map(mouseY / scaleFactor, 0, targetDisplayHeight, -5, 5); 
    if (bg && bg.width > 0) {
        image(bg, targetDisplayWidth / 2 + offsetX, targetDisplayHeight / 2 + offsetY);
    } else {
        background(0);
    }

    if (gameState === 'SPLASH_SCREEN') {
        let blackOverlayAlpha = map(millis() - splashStartTime, 0, SPLASH_FADE_IN_DURATION, 255, 0);
        blackOverlayAlpha = constrain(blackOverlayAlpha, 0, 255);
        fill(0, blackOverlayAlpha);
        rect(0, 0, targetDisplayWidth, targetDisplayHeight);
        
        let elapsedTime = millis() - splashStartTime;
        let alpha = 0;

        if (elapsedTime < SPLASH_FADE_IN_DURATION) {
            alpha = map(elapsedTime, 0, SPLASH_FADE_IN_DURATION, 0, 255);
        } else if (elapsedTime < SPLASH_FADE_IN_DURATION + SPLASH_HOLD_DURATION) {
            alpha = 255;
        } else if (elapsedTime < TOTAL_SPLASH_DURATION) {
            alpha = map(elapsedTime, SPLASH_FADE_IN_DURATION + SPLASH_HOLD_DURATION, TOTAL_SPLASH_DURATION, 255, 0);
        } else {
            gameState = 'WELCOME_SCREEN';
            return;
        }

        tint(255, alpha);
        if (logobambooImg && logobambooImg.width > 0) {
            let logoWidth = 120;
            let logoHeight = 120;
            image(logobambooImg, targetDisplayWidth / 2, targetDisplayHeight / 2, logoWidth, logoHeight);
        }
        noTint();
        return;
    }

    // Рисуем кнопку смены языка ТОЛЬКО на экранах WELCOME_SCREEN и MENU
    const langButtonSize = 24;
    const langButtonX = targetDisplayWidth - 15;
    const langButtonY = 15;
    if (languageImg && languageImg.width > 0 &&
        (gameState === 'WELCOME_SCREEN' || gameState === 'MENU')) {
        image(languageImg, langButtonX, langButtonY, langButtonSize, langButtonSize);
    }


    if (gameState === 'WELCOME_SCREEN') {
        drawWelcomeScreen();
        drawBonusNotifications(); 
        return;
    }

    if (gameState === 'MENU') {
        drawMenu();
        drawBonusNotifications(); 
        return;
    }

    let now = millis();

    if (gameState === 'PLAYING') {
        let gameTime = now - elapsedPauseTime;

        if (floor(clickCount / clicksForSpeedIncrease) > speedIncreaseCounter) {
            if (currentBaseBambooSpeed < maxBambooFallSpeed) {
                currentBaseBambooSpeed += speedIncreaseAmount;
                console.log("Скорость бамбука увеличена до: " + currentBaseBambooSpeed.toFixed(1) + " (клики: " + clickCount + ")");
                saveGameData();
            }
            speedIncreaseCounter++;
        }

        if (gameTime - lastInteractionTime > motivatorThreshold && !motivatorActive && lives > 0) {
            motivatorActive = true;
            motivatorStartTime = gameTime;
            lifeLossPending = true;
            console.log("Рыжик стал мотиватором. Ожидание 5 секунд для потери жизни.");
        }

        if (motivatorActive && gameTime - motivatorStartTime > motivatorDuration) {
            motivatorActive = false;
            if (lifeLossPending) {
                lives -= healthLossOnInactivity;
                console.log("Рыжик закончил быть мотиватором. Потеряна жизнь. Жизней осталось: " + lives);
                lifeLostDuringGame = true; 
                lastHealthLossTime = gameTime;
                if (lives <= 0) {
                    lives = 0;
                    gameState = 'GAME_OVER';
                    if (bgMusic && bgMusic.isPlaying()) {
                        bgMusic.stop(); // Музыка остановлена при GAME_OVER
                        console.log("Music stopped on GAME_OVER.");
                    }
                }
                checkAchievements(); 
                saveGameData(true);
            }
            lifeLossPending = false;
        }

        for (let i = activeExtraHearts.length - 1; i >= 0; i--) {
            if (now - activeExtraHearts[i].startTime > EXTRA_HEART_DURATION) {
                activeExtraHearts.splice(i, 1);
                console.log("Дополнительное сердце истекло.");
        
                // Пересчитываем maxLives сразу же
                maxLives = 3 + (maxLivesUpgradesCount * 1) + activeExtraHearts.length;
                lives = constrain(lives, 0, maxLives);
        
                saveGameData();
            }
        }
        
        // !!! ВАЖНО: maxLives нужно пересчитывать здесь, чтобы UI корректно отображал и constrain работал
        maxLives = 3 + (maxLivesUpgradesCount * 1) + activeExtraHearts.length; 
        lives = constrain(lives, 0, maxLives);


        if (toyBoostActive && now - toyBoostStartTime > TOY_BOOST_DURATION) {
            toyBoostActive = false;
            motivatorThreshold = 30000;
            console.log("Эффект игрушки Рыжика истек.");
            saveGameData();
        } else if (toyBoostActive) {
            motivatorThreshold = 30000 + TOY_BOOST_VALUE;
        }

        let effectiveBambooFallSpeed = currentBaseBambooSpeed;
        if (bambooSlowdownActive) {
            if (now - bambooSlowdownStartTime < BAMBOO_SLOWDOWN_DURATION) {
                effectiveBambooFallSpeed = INITIAL_BAMBOO_FALL_SPEED;
                fill(255);
                stroke(0);
                strokeWeight(2);
                textSize(12);
                textAlign(RIGHT, TOP);
                let timeLeft = Math.ceil((bambooSlowdownStartTime + BAMBOO_SLOWDOWN_DURATION - (now - elapsedPauseTime)) / 1000); 
                text(getTranslation('slowdown') + ": " + timeLeft + getTranslation('seconds_short'), targetDisplayWidth - 10, targetDisplayHeight - 100);
                noStroke();
            } else {
                bambooSlowdownActive = false;
                saveGameData();
            }
        }

        if (inventoryOpen) {
            drawInventory();
        } else {
            let ryzhikX = targetDisplayWidth / 2;
            let ryzhikY = targetDisplayHeight / 2 + 10 + 40;
            let ryzhikW = 128;
            let ryzhikH = 128;

            let nextRyzhikImage = ryzhikIdle;

            if (motivatorActive) {
                nextRyzhikImage = ryzhikMotivatorImg;
            } else if (yawnStage === 1) {
                nextRyzhikImage = ryzhikYawnStart;
                if (!firstYawnAchieved) { 
                    firstYawnAchieved = true;
                    checkAchievements(); 
                }
            } else if (yawnStage === 2) {
                nextRyzhikImage = ryzhikYawnFull;
                if (!firstYawnAchieved) { 
                    firstYawnAchieved = true;
                    checkAchievements(); 
                }
            } else if (feeding) {
                nextRyzhikImage = ryzhikMouthOpen;
            } else if (draggingBamboo && 
                mouseX / scaleFactor > ryzhikX - ryzhikW / 2 &&
                mouseX / scaleFactor < ryzhikX + ryzhikW / 2 &&
                mouseY / scaleFactor > ryzhikY - ryzhikH / 2 && 
                mouseY / scaleFactor < ryzhikY + ryzhikH / 2) { 
                nextRyzhikImage = ryzhikMouthOpen;
            }
            else if (draggingApple && 
                mouseX / scaleFactor > ryzhikX - ryzhikW / 2 &&
                mouseX / scaleFactor < ryzhikX + ryzhikW / 2 &&
                mouseY / scaleFactor > ryzhikY - ryzhikH / 2 && 
                mouseY / scaleFactor < ryzhikY + ryzhikH / 2) { 
                nextRyzhikImage = ryzhikMouthOpen;
            }
            else if (lives === 1) {
                nextRyzhikImage = ryzhikSad;
            } else {
                nextRyzhikImage = ryzhikIdle;
            }

            if (nextRyzhikImage && nextRyzhikImage.width > 0) {
                currentImage = nextRyzhikImage;
                image(currentImage, ryzhikX, ryzhikY);
            }

            if (feeding) {
                if (now - feedingStartTime > feedingDelay) {
                    feeding = false;
                } else {
                    if (frameCount % 5 === 0) {
                        hearts.push({
                            x: targetDisplayWidth / 2 + random(-30, 30),
                            y: targetDisplayHeight / 2 + 10 + 40 - 60 + random(-10, 10),
                            alpha: 255
                        });
                    }
                }
            } else if (!motivatorActive && gameTime - lastYawnTime > 30000 && yawnStage === 0) {
                yawnStage = 1;
                setTimeout(() => {
                    if (gameState === 'PLAYING') {
                        yawnStage = 2;
                        setTimeout(() => {
                            if (gameState === 'PLAYING') {
                                yawnStage = 0;
                                lastYawnTime = gameTime;
                            }
                        }, 1000);
                    }
                }, 500);
            }

            for (let i = hearts.length - 1; i >= 0; i--) {
                let h = hearts[i];
                h.y -= 1;
                h.alpha -= 2;
                if (heartImg && heartImg.width > 0) {
                    tint(255, h.alpha);
                    image(heartImg, h.x, h.y, 14, 14);
                    noTint();
                }
                if (h.alpha <= 0) {
                    hearts.splice(i, 1);
                }
            }

            for (let i = bamboos.length - 1; i >= 0; i--) {
                let b = bamboos[i];
                b.y += effectiveBambooFallSpeed;
                if (bambooImg && bambooImg.width > 0) {
                    image(bambooImg, b.x, b.y, 14, 28);
                }
                if (b.y > targetDisplayHeight + 20) {
                    bamboos.splice(i, 1);
                    lives--;
                    if (lives <= 0) {
                        lives = 0;
                        gameState = 'GAME_OVER';
                        if (bgMusic && bgMusic.isPlaying()) {
                            bgMusic.stop(); // Музыка остановлена при GAME_OVER
                            console.log("Music stopped on GAME_OVER.");
                        }
                    }
                    lifeLostDuringGame = true; 
                    checkAchievements(); 
                    saveGameData(true);
                }
            }

            for (let i = apples.length - 1; i >= 0; i--) {
                let a = apples[i];
                a.y += effectiveBambooFallSpeed;
                if (appleImg && appleImg.width > 0) {
                    image(appleImg, a.x, a.y, 20, 20); 
                }
                if (a.y > targetDisplayHeight + 20) {
                    apples.splice(i, 1); 
                }
            }

            // Отрисовка UI элементов
            if (clickWindowImg && clickWindowImg.width > 0) {
                image(clickWindowImg, 60, 40);
            }
            noStroke();
            fill(0);
            textSize(16);
            text(totalClickCount, 60, 15); 
            text(clickCount, 60, 40); 

            if (bambooWindowImg && bambooWindowImg.width > 0) {
                image(bambooWindowImg, 60, targetDisplayHeight - 40);
            }
            fill(0);
            textSize(16);
            text(collectedBamboo, 60, targetDisplayHeight - 40);

            if (putInventImg && putInventImg.width > 0) {
                image(putInventImg, targetDisplayWidth - 20, 20, 32, 32);
            }

            let heartDisplayOffsetX = 10;
            let heartDisplayOffsetY = 50;
            if (heartFrameImg && heartFrameImg.width > 0) {
                image(heartFrameImg, heartDisplayOffsetX + 32, heartDisplayOffsetY + 12, 64, 24);
            }
            for (let i = 0; i < lives; i++) {
                if (heartIconImg && heartIconImg.width > 0) {
                    image(heartIconImg, heartDisplayOffsetX + 8 + i * 18, heartDisplayOffsetY + 12, 16, 16);
                }
            }
            for (let i = lives; i < maxLives; i++) {
                if (heartIconImg && heartIconImg.width > 0) {
                    tint(255, 100);
                    image(heartIconImg, heartDisplayOffsetX + 8 + i * 18, heartDisplayOffsetY + 12, 16, 16);
                    noTint();
                }
            }

            let pauseButtonX = targetDisplayWidth - 32;
            let pauseButtonY = targetDisplayHeight - 42.7;
            if (pauseButtonImg && pauseButtonImg.width > 0) {
                image(pauseButtonImg, pauseButtonX, pauseButtonY, 32, 32);
            }

            let shopButtonX = targetDisplayWidth - 60;
            let shopButtonY = 20;
            if (shopButtonImg && shopButtonImg.width > 0) {
                image(shopButtonImg, shopButtonX, shopButtonY, 32, 32);
            }

        }

        // ОРИГИНАЛЬНАЯ ЛОГИКА ДЛЯ ПЕРЕТАСКИВАЕМЫХ ЭЛЕМЕНТОВ
        if (draggingBamboo) {
            if (bambooElementImg && bambooElementImg.width > 0) {
                image(bambooElementImg, dragX / scaleFactor, dragY / scaleFactor, 32, 32);
            }
        }
        else if (draggingApple) {
            if (appleElementImg && appleElementImg.width > 0) {
                image(appleElementImg, dragX / scaleFactor, dragY / scaleFactor, 32, 32);
            }
        }

        drawNotifications();

    } else if (gameState === 'PAUSED') {
        let offsetX = map(mouseX / scaleFactor, 0, targetDisplayWidth, -5, 5);
        let offsetY = map(mouseY / scaleFactor, 0, targetDisplayHeight, -5, 5);
        if (bg && bg.width > 0) {
            image(bg, targetDisplayWidth / 2 + offsetX, targetDisplayHeight / 2 + offsetY);
        }

        fill(50, 50, 50, 150);
        rect(0, 0, targetDisplayWidth, targetDisplayHeight);
        fill(255);
        textSize(32);
        textAlign(CENTER, CENTER); 
        text(getTranslation('pause_title'), targetDisplayWidth / 2, targetDisplayHeight / 2 - 80);

        textSize(10);
        text(getTranslation('continue_game_tip'), targetDisplayWidth / 2, targetDisplayHeight / 2 - 50);

        let buttonSize = 32;

        let playButtonX = targetDisplayWidth / 2;
        let playButtonY = targetDisplayHeight / 2; 
        if (playButtonImg && playButtonImg.width > 0) {
            image(playButtonImg, playButtonX, playButtonY, buttonSize, buttonSize);
        }

        let achievementsButtonX = targetDisplayWidth / 2;
        let achievementsButtonY = playButtonY + buttonSize + 10; 

        if (achievementsButtonImg && achievementsButtonImg.width > 0) {
            image(achievementsButtonImg, achievementsButtonX, achievementsButtonY, buttonSize, buttonSize);
            textSize(12);
            fill(255);
            textAlign(CENTER, CENTER); 
            text(getTranslation('achievements_button'), achievementsButtonX, achievementsButtonY + buttonSize / 2 + 10); 
        }

        let soundButtonX = targetDisplayWidth / 2;
        let soundButtonY = achievementsButtonY + buttonSize + 10 + 30; 
        
        if (isMusicOn) {
            if (soundOnImg && soundOnImg.width > 0) {
                image(soundOnImg, soundButtonX, soundButtonY, buttonSize, buttonSize);
            }
        } else {
            if (soundOffImg && soundOffImg.width > 0) {
                image(soundOffImg, soundButtonX, soundButtonY, buttonSize, buttonSize);
            }
        }
    } else if (gameState === 'SHOP') {
        drawShop();
    } else if (gameState === 'GAME_OVER') {
        drawGameOverScreen();
    }
    else if (gameState === 'ACHIEVEMENTS_SCREEN') {
        drawAchievementsScreen();

    }
}

function drawNotifications() {
    let now = millis();
    let targetDisplayWidth = width / scaleFactor;
    let targetDisplayHeight = height / scaleFactor;

    for (let i = achievementsNotificationQueue.length - 1; i >= 0; i--) {
        let notification = achievementsNotificationQueue[i];
        let elapsedTime = now - notification.startTime;

        let alpha = 0;
        if (elapsedTime < NOTIFICATION_FADE_DURATION) {
            alpha = map(elapsedTime, 0, NOTIFICATION_FADE_DURATION, 0, 255);
        } else if (elapsedTime < NOTIFICATION_DURATION - NOTIFICATION_FADE_DURATION) {
            alpha = 255;
        } else if (elapsedTime < NOTIFICATION_DURATION) {
            alpha = map(elapsedTime, NOTIFICATION_DURATION - NOTIFICATION_FADE_DURATION, NOTIFICATION_DURATION, 255, 0);
        } else {
            achievementsNotificationQueue.splice(i, 1);
            continue; 
        }

        push(); 
        stroke(0); 
        strokeWeight(2); 
        
        fill(255, alpha); 
        textAlign(CENTER, CENTER);

        textSize(16); 
        text(notification.messageHeader, targetDisplayWidth / 2, targetDisplayHeight - 140); 
        textSize(14); 
        text(notification.messageText, targetDisplayWidth / 2, targetDisplayHeight - 120); 
        
        pop(); 
    }
}

function disableZoom() {
  // Блокировка масштабирования через Ctrl + колесо мыши
  window.addEventListener('wheel', function(e) {
    if (e.ctrlKey) e.preventDefault();
  }, { passive: false });

  // Блокировка pinch-to-zoom (щипка) на сенсорных устройствах
  window.addEventListener('gesturestart', function(e) {
    e.preventDefault();
  });

  // Блокировка двойного тапа на мобильных устройствах
  let lastTouchEnd = 0;
  window.addEventListener('touchend', function(e) {
    let now = (new Date()).getTime();
    if (now - lastTouchEnd <= 300) {
      e.preventDefault();
    }
    lastTouchEnd = now;
  }, false);
}

// Вызов при запуске игры
disableZoom();


// === ФУНКЦИЯ ДЛЯ ОТРИСОВКИ ВСПЛЫВАЮЩИХ БОНУСОВ ===
function drawBonusNotifications() {
    let now = millis();

    for (let i = bonusNotifications.length - 1; i >= 0; i--) {
        let notification = bonusNotifications[i];
        let elapsedTime = now - notification.startTime;

        let alpha = 0;
        if (elapsedTime < BONUS_NOTIFICATION_FADE_DURATION) {
            alpha = map(elapsedTime, 0, BONUS_NOTIFICATION_FADE_DURATION, 0, 255);
        } else if (elapsedTime < BONUS_NOTIFICATION_DURATION - BONUS_NOTIFICATION_FADE_DURATION) {
            alpha = 255;
        } else if (elapsedTime < BONUS_NOTIFICATION_DURATION) {
            alpha = map(elapsedTime, BONUS_NOTIFICATION_DURATION - BONUS_NOTIFICATION_FADE_DURATION, BONUS_NOTIFICATION_DURATION, 255, 0);
        } else {
            bonusNotifications.splice(i, 1); 
            continue;
        }

        let currentY = notification.y - map(elapsedTime, 0, BONUS_NOTIFICATION_DURATION, 0, 30); 

        push(); 
        noStroke(); 
        fill(255, alpha); 
        textSize(10); // Уменьшен размер текста для бонусного уведомления
        textAlign(CENTER, CENTER); 
        text(notification.text, notification.x, currentY); 
        pop(); 
    }
}
// =======================================================

function drawWelcomeScreen() {
    let targetDisplayWidth = width / scaleFactor;
    let targetDisplayHeight = height / scaleFactor;

    fill(0, 0, 0, 150);
    rect(0, 0, targetDisplayWidth, targetDisplayHeight);

    if (logobambooImg && logobambooImg.width > 0) {
        image(logobambooImg, targetDisplayWidth / 2, targetDisplayHeight / 2 - 120, 120, 120);
    }
    
    fill(255);
    noStroke();
    textAlign(CENTER, CENTER);
    textSize(20);
    text(getTranslation('clickerpanda_title'), targetDisplayWidth / 2, targetDisplayHeight / 2 - 30);
    
    
    let playButtonX = targetDisplayWidth / 2;
    let playButtonY = targetDisplayHeight / 2 + 60;
    let buttonWidth = 100;
    let buttonHeight = 40;

    function drawButton(x, y, label, width, height) {
        if (aboutImage && aboutImage.width > 0) {
            image(aboutImage, x, y, width, height);
            fill(0);
            textSize(18); 
            textAlign(CENTER, CENTER);
            text(label, x, y);
        } else {
            fill(0, 200, 0);
            rect(x - width / 2, y - height / 2, width, height);
            fill(255);
            textSize(16);
            textAlign(CENTER, CENTER);
            text(label, x, y);
        }
    }

    drawButton(playButtonX, playButtonY, getTranslation('play_button'), buttonWidth, buttonHeight);
}

function drawInventory() {
    let targetDisplayWidth = width / scaleFactor;
    let targetDisplayHeight = height / scaleFactor;

    fill(0, 0, 0, 150);
    rect(0, 0, targetDisplayWidth, targetDisplayHeight);

    if (inventImg && inventImg.width > 0) {
        image(inventImg, targetDisplayWidth / 2, targetDisplayHeight / 2);
    }
    fill(255);
    textSize(16);
    textAlign(CENTER, CENTER);
    text(getTranslation('bag_of_bamboo'), targetDisplayWidth / 2, 30);

    textSize(14);
    text(getTranslation('bamboo_count') + collectedBamboo, targetDisplayWidth / 2 - 40, 70);
    text(getTranslation('apples_count') + collectedApple, targetDisplayWidth / 2 + 40, 70);

    textSize(12);
    text(getTranslation('exit_inventory_tip'), targetDisplayWidth / 2, targetDisplayHeight - 20);
    if (putInventImg && putInventImg.width > 0) {
        image(putInventImg, targetDisplayWidth - 20, 20, 32, 32);
    }

    let invItemSize = 32;
    let invItemY = targetDisplayHeight / 2 - 40 + 20; 

    if (collectedBamboo > 0) {
        if (bambooElementImg && bambooElementImg.width > 0) {
            image(bambooElementImg, targetDisplayWidth / 2 - 30, invItemY, invItemSize, invItemSize);
        }
    }
    if (collectedApple > 0) {
        if (appleElementImg && appleElementImg.width > 0) {
            image(appleElementImg, targetDisplayWidth / 2 + 30, invItemY, invItemSize, invItemSize); 
        }
    }
}

function drawMenu() {
    let targetDisplayWidth = width / scaleFactor;
    let targetDisplayHeight = height / scaleFactor;

    fill(0, 0, 0, 150);
    rect(0, 0, targetDisplayWidth, targetDisplayHeight);

    fill(255);
    noStroke();
    textAlign(CENTER, CENTER);
    textSize(20);
    text(getTranslation('clickerpanda_title'), targetDisplayWidth / 2, targetDisplayHeight / 2 - 30); 
    

    let playButtonMenuX = targetDisplayWidth / 2;
    let playButtonMenuY = targetDisplayHeight / 2 + 60;
    let buttonWidth = 100;
    let buttonHeight = 40;

    function drawButton(x, y, label, width, height) {
        if (aboutImage && aboutImage.width > 0) {
            image(aboutImage, x, y, width, height);
            fill(0);
            textSize(18); 
            textAlign(CENTER, CENTER);
            text(label, x, y);
        } else {
            fill(0, 200, 0);
            rect(x - width / 2, y - height / 2, width, height);
            fill(255);
            textSize(16);
            textAlign(CENTER, CENTER);
            text(label, x, y);
        }
    }
    
    drawButton(playButtonMenuX, playButtonMenuY, getTranslation('play_button'), buttonWidth, buttonHeight);
}

function drawShop() {
    let targetDisplayWidth = width / scaleFactor;
    let targetDisplayHeight = height / scaleFactor;

    fill(0, 0, 0, 150);
    rect(0, 0, targetDisplayWidth, targetDisplayHeight);

    fill(255);
    textSize(24);
    text(getTranslation('shop_title'), targetDisplayWidth / 2, 50);

    textSize(16);
    text(getTranslation('your_clicks') + clickCount, targetDisplayWidth / 2, 80);

    let itemY = 120;
    let itemSpacing = 60;

    let buttonWidth = 100;
    let buttonHeight = 30;
    let buyButtonAreaX = targetDisplayWidth / 2 + 50;

    function drawBuyButton(x, y, label) {
        if (aboutImage && aboutImage.width > 0) {
            image(aboutImage, x, y, buttonWidth, buttonHeight);
            fill(0);
            textSize(16);
            textAlign(CENTER, CENTER);
            text(label, x, y);
        } else {
            fill(0, 200, 0);
            rect(x - buttonWidth / 2, y - buttonHeight / 2, width, height);
            fill(255);
            textSize(12);
            textAlign(CENTER, CENTER);
            text(label, x, y);
        }
    }

    fill(255);
    textSize(10);
    textAlign(LEFT, TOP);
    text(getTranslation('extra_heart'), 8, itemY);
    text(getTranslation('cost') + EXTRA_HEART_COST + getTranslation('clicks_short'), 8, itemY + 15);

    let activeHeartsCount = activeExtraHearts.length;
    if (activeHeartsCount > 0) {
        textSize(10);
        let oldestHeartTimeLeft = Math.ceil((activeExtraHearts[0].startTime + EXTRA_HEART_DURATION - (millis() - elapsedPauseTime)) / 1000);
        text(getTranslation('active') + activeHeartsCount + getTranslation('until_seconds') + oldestHeartTimeLeft + getTranslation('seconds_short'), 50, itemY + 30);
    }

    // --- ИСПРАВЛЕНИЕ ЛОГИКИ ПОКУПКИ "ДОП. СЕРДЦА" ---
    // Доп. сердце - это временный эффект, позволяем купить только одно активное
    if (activeExtraHearts.length === 0) { 
        drawBuyButton(buyButtonAreaX, itemY + 15, getTranslation('buy_button'));
    } else {
        fill(100);
        textSize(14);
        textAlign(CENTER, CENTER);
        text(getTranslation('already_active'), buyButtonAreaX, itemY + 15); // Новый текст "Уже активно"
    }
    // ----------------------------------------------------
    itemY += itemSpacing;

    fill(255);
    textSize(10);
    textAlign(LEFT, TOP);
    text(getTranslation('toy'), 8, itemY);
    text(getTranslation('cost') + TOY_COST + getTranslation('clicks_short'), 8, itemY + 15);

    if (toyBoostActive) {
        textSize(10);
        let timeLeft = Math.ceil((toyBoostStartTime + TOY_BOOST_DURATION - (millis() - elapsedPauseTime)) / 1000);
        text(getTranslation('active') + timeLeft + getTranslation('seconds_short'), 50, itemY + 30);
    }

    if (toyUpgradesCount < MAX_TOY_BUYS) {
        drawBuyButton(buyButtonAreaX, itemY + 15, getTranslation('buy_button'));
    } else {
        fill(100);
        textSize(14);
        textAlign(CENTER, CENTER);
        text(getTranslation('max_bought'), buyButtonAreaX, itemY + 15);
    }
    itemY += itemSpacing;

    fill(255);
    textSize(10);
    textAlign(LEFT, TOP);
    text(getTranslation('bamboo_slowdown'), 8, itemY);
    text(getTranslation('cost') + BAMBOO_SLOWDOWN_COST + getTranslation('clicks_short'), 8, itemY + 15);

    if (bambooSlowdownActive) {
        textSize(10);
        let timeLeft = Math.ceil((bambooSlowdownStartTime + BAMBOO_SLOWDOWN_DURATION - (millis() - elapsedPauseTime)) / 1000);
        text(getTranslation('active') + timeLeft + getTranslation('seconds_short'), 50, itemY + 30);
    }

    if (!bambooSlowdownActive) {
        drawBuyButton(buyButtonAreaX, itemY + 15, getTranslation('buy_button'));
    } else {
        fill(100);
        textSize(14);
        textAlign(CENTER, CENTER);
        text(getTranslation('bamboo_slowdown_active'), buyButtonAreaX, itemY + 15);
    }
    itemY += itemSpacing; 

    let backButtonX = targetDisplayWidth / 2;
    let backButtonY = targetDisplayHeight - 50;
    drawBuyButton(backButtonX, backButtonY + buttonHeight / 2, getTranslation('back_button'));

    checkAchievements();
}

function drawGameOverScreen() {
    let targetDisplayWidth = width / scaleFactor;
    let targetDisplayHeight = height / scaleFactor;

    if (gameOverScreenImg && gameOverScreenImg.width > 0) {
        image(gameOverScreenImg, targetDisplayWidth / 2, targetDisplayHeight / 2, targetDisplayWidth, targetDisplayHeight);
    }

    fill(255);
    noStroke();
    textAlign(CENTER, CENTER);

    textSize(8); 
    let initialTipY = targetDisplayHeight / 2 + 10;

    text(getTranslation('game_over_tip_header'), targetDisplayWidth / 2, initialTipY);
    text(getTranslation('game_over_tip_line1'), targetDisplayWidth / 2, initialTipY + 20);
    text(getTranslation('game_over_tip_line2'), targetDisplayWidth / 2, initialTipY + 30);
    text(getTranslation('game_over_tip_line3'), targetDisplayWidth / 2, initialTipY + 50);
    text(getTranslation('game_over_tip_line4'), targetDisplayWidth / 2, initialTipY + 60);

    // НОВАЯ КНОПКА "Начать новую игру"
    let buttonX = targetDisplayWidth / 2;
    let buttonY = targetDisplayHeight / 2 + 150; // Позиция кнопки
    let buttonWidth = 150;
    let buttonHeight = 40;

    function drawSimpleButton(x, y, label, width, height) {
        if (loadgameoverImg && loadgameoverImg.width > 0) {
            image(loadgameoverImg, x, y, width, height);
            fill(0); // Цвет текста на кнопке
            textSize(10);
            textAlign(CENTER, CENTER);
            text(label, x, y + 1);
        } else {
            // Запасной вариант, если aboutImage не загружено
            fill(0, 200, 0);
            rect(x - width / 2, y - height / 2, width, height);
            fill(255);
            textSize(10);
            textAlign(CENTER, CENTER);
            text(label, x, y);
        }
    }
    drawSimpleButton(buttonX, buttonY, getTranslation('game_over_start_new_game'), buttonWidth, buttonHeight);
}

function drawAchievementsScreen() {
    let targetDisplayWidth = width / scaleFactor;
    let targetDisplayHeight = height / scaleFactor;

    fill(0, 0, 0, 180); 
    rect(0, 0, targetDisplayWidth, targetDisplayHeight);

    fill(255);
    textSize(24);
    textAlign(CENTER, CENTER);
    text(getTranslation('achievements_screen_title'), targetDisplayWidth / 2, 20); // Заголовок

    let displayAreaX = 20;
    let displayAreaY = 50; 
    
    let backButtonHeight = 30; 
    let tempBackButtonY = targetDisplayHeight - 50; 
    let backButtonTopEdgeY = tempBackButtonY - (backButtonHeight / 2); 
    let paddingAboveButton = 15; 
    let clippedAreaBottomY = backButtonTopEdgeY - paddingAboveButton;
    let displayAreaHeight = clippedAreaBottomY - displayAreaY;
    
    let displayAreaWidth = targetDisplayWidth - 2 * displayAreaX; 

    let contentHeight = achievements.length * ACHIEVEMENT_ITEM_HEIGHT; 
    maxScrollOffsetAchievements = max(0, contentHeight - displayAreaHeight); 

    scrollOffsetAchievements = constrain(scrollOffsetAchievements, 0, maxScrollOffsetAchievements);

    push(); 
    rectMode(CORNER);
    drawingContext.save(); 
    drawingContext.beginPath();
    drawingContext.rect(displayAreaX * pixelDensity(), displayAreaY * pixelDensity(), displayAreaWidth * pixelDensity(), displayAreaHeight * pixelDensity());
    drawingContext.clip(); 

    let textOffsetX = displayAreaX + 5; 
    let textStartY = displayAreaY + 10;  

    achievements.forEach((ach, index) => { 
        let currentY = textStartY + index * ACHIEVEMENT_ITEM_HEIGHT - scrollOffsetAchievements;
        let textColor = ach.completed ? color(50, 200, 50) : color(200, 200, 200); 

        fill(textColor);
        textSize(12); 
        textAlign(LEFT, TOP);
        text(getTranslation(ach.name_key), textOffsetX, currentY);

        textSize(9); 
        text(getTranslation(ach.description_key), textOffsetX, currentY + 15, displayAreaWidth - 10);
    });
    drawingContext.restore(); 
    pop(); 

    let backButtonX = targetDisplayWidth / 2;
    let backButtonY = targetDisplayHeight - 50; 
    let buttonWidth = 100;
    let buttonHeight = 30;

    function drawButton(x, y, label, width, height) {
        if (aboutImage && aboutImage.width > 0) {
            image(aboutImage, x, y, width, height);
            fill(0);
            textSize(16);
            textAlign(CENTER, CENTER);
            text(label, x, y);
        } else {
            fill(0, 200, 0);
            rect(x - width / 2, y - height / 2, width, height);
            fill(255);
            textSize(12);
            textAlign(CENTER, CENTER);
            text(label, x, y);
        }
    }

    drawButton(backButtonX, backButtonY + buttonHeight / 2, getTranslation('back_button'), buttonWidth, buttonHeight);
}

function mousePressed(event) { 
    if (!gameReadyToStart) return;
    if (gameState === 'SPLASH_SCREEN') {
        if (millis() - splashStartTime < TOTAL_SPLASH_DURATION) {
            return;
        }
        gameState = 'WELCOME_SCREEN';
        return;
    }

    // Добавляем event.preventDefault() для отключения контекстного меню и выделения
    if (event.cancelable) { 
        event.preventDefault(); 
    }

    let mx = mouseX / scaleFactor; 
    let my = mouseY / scaleFactor; 

    let targetDisplayWidth = width / scaleFactor; 
    let targetDisplayHeight = height / scaleFactor; 
    let buttonSize = 32; 
    let largeButtonWidth = 100; 
    let largeButtonHeight = 40; 

    function isButtonClicked(buttonX, buttonY, buttonW, buttonH) {
        return mx > buttonX - buttonW / 2 && mx < buttonX + buttonW / 2 &&
               my > buttonY - buttonH / 2 && my < buttonY + buttonH / 2;
    }

    // Обработка клика по кнопке смены языка - только на WELCOME_SCREEN и MENU
    const langButtonSize = 24;
    const langButtonX = targetDisplayWidth - 15;
    const langButtonY = 15;
    if ((gameState === 'WELCOME_SCREEN' || gameState === 'MENU') && dist(mx, my, langButtonX, langButtonY) < langButtonSize / 2) {
        currentLanguage = (currentLanguage === 'ru') ? 'en' : 'ru';
        console.log("Language switched to:", currentLanguage);
        saveGameData(true); 
        return; 
    }


    if (gameState === 'WELCOME_SCREEN') {
        let playButtonMenuX = targetDisplayWidth / 2;
        let playButtonMenuY = targetDisplayHeight / 2 + 60;
        
        if (isButtonClicked(playButtonMenuX, playButtonMenuY, largeButtonWidth, largeButtonHeight)) {
            gameState = 'PLAYING';

            // Вызов полноэкранного режима по действию пользователя
            if (ysdk && ysdk.deviceInfo && ysdk.deviceInfo.isMobileBrowser && ysdk.deviceInfo.isMobileBrowser()) {
                requestFullscreenGame();
            }

            if (!musicStarted) {
                if (bgMusic) {
                    bgMusic.loop();
                    musicStarted = true;
                    bgMusic.setVolume(isMusicOn ? musicVolume : 0);
                    console.log("Music started looping from WELCOME_SCREEN.");
                }
            }

            lastInteractionTime = millis();
            lastYawnTime = millis();
            lastHealthLossTime = millis();
            elapsedPauseTime = 0;
            motivatorActive = false;
            lifeLossPending = false;
            yawnStage = 0;
            feeding = false;
            currentImage = ryzhikIdle;
            
            saveGameData(true);
            return;
        }
        return;
    }

    if (gameState === 'MENU') {
        let playButtonMenuX = targetDisplayWidth / 2;
        let playButtonMenuY = targetDisplayHeight / 2 + 60;

        if (isButtonClicked(playButtonMenuX, playButtonMenuY, largeButtonWidth, largeButtonHeight)) {
            gameState = 'PLAYING';

            if (ysdk && ysdk.deviceInfo && ysdk.deviceInfo.isMobileBrowser && ysdk.deviceInfo.isMobileBrowser()) {
                requestFullscreenGame();
            }

            if (!musicStarted) {
                if (bgMusic) {
                    bgMusic.loop();
                    musicStarted = true;
                    console.log("Music started looping from MENU.");
                }
            }

            let now = millis();
            lastInteractionTime = now;
            lastYawnTime = now;
            lastHealthLossTime = now;
            elapsedPauseTime = 0;
            motivatorActive = false;
            lifeLossPending = false;
            yawnStage = 0;
            feeding = false;
            currentImage = ryzhikIdle;
            saveGameData(true);

            return;
        }
        return;
    }

    if (gameState === 'GAME_OVER') {
        let gameOverButtonX = targetDisplayWidth / 2;
        let gameOverButtonY = targetDisplayHeight / 2 + 150;
        let gameOverButtonWidth = 100;
        let gameOverButtonHeight = 40;

        if (isButtonClicked(gameOverButtonX, gameOverButtonY, gameOverButtonWidth, gameOverButtonHeight)) {
            showFullscreenAd(); // Показываем рекламу перед сбросом и новой сессии
            saveGameData(true); // Сохраняем состояние
    
            if (bgMusic && bgMusic.isPlaying()) {
                bgMusic.stop(); // 🛑 Останавливаем музыку, чтобы не наложилась при новой игре
            }
    
            resetGame(); // Сброс игры без сброса общих достижений
            console.log("Game over screen: New game started and reset.");
        }
        return;
    }

    if (gameState === 'PLAYING') {
        let pauseButtonX = targetDisplayWidth - 32;
        let pauseButtonY = targetDisplayHeight - 42.7;
        if (isButtonClicked(pauseButtonX, pauseButtonY, buttonSize, buttonSize)) {
            gameState = 'PAUSED';
            pauseStartTime = millis();
            motivatorActive = false;
            lifeLossPending = false;
            saveGameData(true);
            console.log("Game paused.");
            return;
        }

        let shopButtonX = targetDisplayWidth - 60;
        let shopButtonY = 20;
        if (isButtonClicked(shopButtonX, shopButtonY, buttonSize, buttonSize)) {
            gameState = 'SHOP';
            motivatorActive = false;
            lifeLossPending = false;
            saveGameData(true);
            console.log("Shop opened.");
            return;
        }
    } else if (gameState === 'PAUSED') {
        let buttonSize = 32;

        let playButtonX = targetDisplayWidth / 2;
        let playButtonY = targetDisplayHeight / 2; 
        
        let achievementsButtonX = targetDisplayWidth / 2;
        let achievementsButtonY = playButtonY + buttonSize + 10; 

        if (isButtonClicked(playButtonX, playButtonY, buttonSize, buttonSize)) {
            gameState = 'PLAYING';
            elapsedPauseTime += millis() - pauseStartTime;

            let now = millis();
            let gameTimeAfterPause = now - elapsedPauseTime;
            lastInteractionTime = gameTimeAfterPause;
            lastYawnTime = gameTimeAfterPause;
            lastHealthLossTime = gameTimeAfterPause;
            yawnStage = 0;
            feeding = false;
            currentImage = ryzhikIdle;

            motivatorActive = false;
            lifeLossPending = false;
            saveGameData(true);
            console.log("Game resumed from PAUSED screen.");
            return; 
        }

        if (isButtonClicked(achievementsButtonX, achievementsButtonY + buttonSize / 2 + 10, buttonSize * 1.5, buttonSize * 1.5)) {
            gameState = 'ACHIEVEMENTS_SCREEN';
            calculateMaxScrollOffsetAchievements(achievements.length); 
            console.log("Achievements screen opened from PAUSED.");
            return; 
        }

        let soundButtonX = targetDisplayWidth / 2;
        let soundButtonY = achievementsButtonY + buttonSize + 10 + 30; 
        
        if (isButtonClicked(soundButtonX, soundButtonY, buttonSize, buttonSize)) {
            isMusicOn = !isMusicOn;
            if (isMusicOn) {
                if (bgMusic) {
                    bgMusic.setVolume(musicVolume);
                    console.log(`Music turned ON, volume set to ${musicVolume}.`);
                }
            } else {
                if (bgMusic) {
                    bgMusic.setVolume(0);
                    console.log("Music turned OFF.");
                }
            }
            saveGameData(true);
            return; 
        }
        
        return; 
    } else if (gameState === 'SHOP') {
        let backButtonX = targetDisplayWidth / 2;
        let backButtonY = targetDisplayHeight - 50;
        let shopButtonWidth = 100;
        let shopButtonHeight = 30;

        if (isButtonClicked(backButtonX, backButtonY + shopButtonHeight / 2, shopButtonWidth, shopButtonHeight)) {
            gameState = 'PLAYING';

            let now = millis();
            let gameTimeAfterShop = now - elapsedPauseTime;
            lastInteractionTime = gameTimeAfterShop;
            lastYawnTime = gameTimeAfterShop;
            lastHealthLossTime = gameTimeAfterShop;
            yawnStage = 0;
            feeding = false;
            currentImage = ryzhikIdle;

            motivatorActive = false;
            lifeLossPending = false;
            saveGameData(true);
            console.log("Shop closed, game resumed.");
            return;
        }

        let itemY = 120;
        let itemSpacing = 60;
        let buyButtonAreaX = targetDisplayWidth / 2 + 50;
        let buttonWidth = 100;
        let buttonHeight = 30;

        // --- ИСПРАВЛЕНИЕ ЛОГИКИ ПОКУПКИ "ДОП. СЕРДЦА" ---
        // Доп. сердце - это временный эффект, позволяем купить только одно активное
        if (activeExtraHearts.length === 0) { 
            let buyButtonY = itemY + 15;
            if (isButtonClicked(buyButtonAreaX, buyButtonY, buttonWidth, buttonHeight)) {
                if (clickCount >= EXTRA_HEART_COST) {
                    clickCount -= EXTRA_HEART_COST;
                    activeExtraHearts.push({
                        startTime: Date.now()

                    });

                    if (maxLivesUpgradesCount === 0) maxLivesUpgradesCount = 1; // 👉 добавь ЭТО СЮДА!

                    // Пересчитываем maxLives ДО изменения lives, чтобы constrain работал корректно
                    maxLives = 3 + (maxLivesUpgradesCount * 1) + activeExtraHearts.length; 
                    lives = constrain(lives + 1, 0, maxLives); // Увеличиваем текущее количество жизней на 1
                    console.log("Куплено сердце! Оно исчезнет через " + (EXTRA_HEART_DURATION / (60 * 1000)) + " минут. Жизней: " + lives + "/" + maxLives);
                    checkAchievements(); 
                    saveGameData(true);
                } else {
                    console.log(getTranslation('not_enough_clicks_heart'));
                }
            }
        }
        itemY += itemSpacing;

        if (toyUpgradesCount < MAX_TOY_BUYS) {
            let buyButtonY = itemY + 15;
            if (isButtonClicked(buyButtonAreaX, buyButtonY, buttonWidth, buttonHeight)) {
                if (clickCount >= TOY_COST) {
                    clickCount -= TOY_COST;
                    toyUpgradesCount++;
                    toyBoostActive = true;
                    toyBoostStartTime = millis() - elapsedPauseTime;
                    console.log("Куплена игрушка Рыжика! Действует " + (TOY_BOOST_DURATION / (60 * 1000)) + " минут.");
                    checkAchievements(); 
                    saveGameData(true);
                } else {
                    console.log(getTranslation('not_enough_clicks_toy'));
                }
            }
        }
        itemY += itemSpacing;

        let slowdownBuyButtonY = itemY + 15; 

        if (!bambooSlowdownActive) {
            if (isButtonClicked(buyButtonAreaX, slowdownBuyButtonY, buttonWidth, buttonHeight)) { 
                if (clickCount >= BAMBOO_SLOWDOWN_COST) {
                    clickCount -= BAMBOO_SLOWDOWN_COST;
                    bambooSlowdownActive = true;
                    bambooSlowdownStartTime = millis() - elapsedPauseTime;
                    console.log("Куплен замедлитель бамбука! Действует 1 минуту.");
                    checkAchievements(); 
                    saveGameData(true);
                } else {
                    console.log(getTranslation('not_enough_clicks_slowdown'));
                }
            }
        }
        itemY += itemSpacing; 

        return;
    }
    else if (gameState === 'ACHIEVEMENTS_SCREEN') {
        let backButtonX = targetDisplayWidth / 2;
        let backButtonY = targetDisplayHeight - 50; 
        let buttonWidth = 100;
        let buttonHeight = 30;

        if (isButtonClicked(backButtonX, backButtonY + buttonHeight / 2, buttonWidth, buttonHeight)) {
            gameState = 'PAUSED'; 
            console.log("Achievements screen closed.");
            return;
        }
        return; 
    }

    if (gameState !== 'PLAYING') return; 

    if (isButtonClicked(targetDisplayWidth - 20, 20, 32, 32)) {
        if (!draggingBamboo && !draggingApple) { 
            inventoryOpen = !inventoryOpen;
            if (!inventoryOpen) {
                let now = millis();
                let gameTimeNow = now - elapsedPauseTime;
                lastInteractionTime = gameTimeNow;
                lastYawnTime = gameTimeNow;
                lastHealthLossTime = gameTimeNow;
                yawnStage = 0;
                currentImage = ryzhikIdle;
                motivatorActive = false;
                lifeLossPending = false;
                saveGameData();
                console.log("Inventory closed.");
            } else {
                saveGameData(true);
                console.log("Inventory opened.");
            }
        }
        return; 
    }

    if (inventoryOpen) { 
        let invItemSize = 32;
        let invItemY = targetDisplayHeight / 2 - 40 + 20;
        let invBambooX = targetDisplayWidth / 2 - 30;
        let invAppleX = targetDisplayWidth / 2 + 30;

        if (collectedBamboo > 0 && isButtonClicked(invBambooX, invItemY, invItemSize, invItemSize)) {
            draggingBamboo = true;
            dragX = mouseX;
            dragY = mouseY;
            inventoryOpen = false;
            console.log("Started dragging bamboo from inventory.");
            return; 
        } else if (collectedApple > 0 && isButtonClicked(invAppleX, invItemY, invItemSize, invItemSize)) {
            draggingApple = true;
            dragX = mouseX;
            dragY = mouseY;
            inventoryOpen = false;
            console.log("Started dragging apple from inventory.");
            return; 
        }
        return;
    }

    let ryzhikX = targetDisplayWidth / 2; 
    let ryzhikY = targetDisplayHeight / 2 + 10 + 40; 
    let ryzhikW = 128;
    let ryzhikH = 128;

    let clickedBamboo = false;

    for (let i = bamboos.length - 1; i >= 0; i--) {
        let b = bamboos[i];
        if (mx > b.x - 7 && mx < b.x + 7 &&
            my > b.y - 14 && my < b.y + 14) { 
            bamboos.splice(i, 1);
            collectedBamboo++;
            clickedBamboo = true;
            lastInteractionTime = millis() - elapsedPauseTime; 
            checkAchievements(); 
            saveGameData();
            console.log("Bamboo collected.");
            break;
        }
    }

    let caughtApple = false;
    for (let i = apples.length - 1; i >= 0; i--) {
        let a = apples[i];
        if (mx > a.x - 10 && mx < a.x + 10 &&
            my > a.y - 10 && my < a.y + 10) {
            apples.splice(i, 1);
            collectedApple++; 
            caughtApple = true;
            console.log("Яблоко поймано! Всего яблок: " + collectedApple);
            lastInteractionTime = millis() - elapsedPauseTime; 
            checkAchievements(); 
            saveGameData();
            break;
        }
    }

    if (!clickedBamboo && !caughtApple && 
        mx > ryzhikX - ryzhikW / 2 &&
        mx < ryzhikX + ryzhikW / 2 &&
        my > ryzhikY - ryzhikH / 2 &&
        my < ryzhikY + ryzhikH / 2
    ) {
        if (millis() - lastHeartSpawnTime > HEART_SPAWN_INTERVAL) {
            hearts.push({
                x: mx,
                y: my,
                alpha: 255
            });
            lastHeartSpawnTime = millis(); 
        }
        
        clickCount++;
        totalClickCount++;
        lastInteractionTime = millis() - elapsedPauseTime;
        lastHealthLossTime = millis() - elapsedPauseTime;
        motivatorActive = false;
        lifeLossPending = false;
        attendedToMotivatorAchieved = true; 

        if (clickCount % 5 === 0) {
            bamboos.push({
                x: random(30, targetDisplayWidth - 30), 
                y: -20,
                spawnTime: millis() - elapsedPauseTime
            });
        }
        if (totalClickCount > 0 && totalClickCount % CLICKS_FOR_APPLE_DROP === 0) {
            spawnApple();
        }
        checkAchievements(); 
        saveGameData();
        console.log("Click on Ryzhik. ClickCount: " + clickCount + ", TotalClickCount: " + totalClickCount);
    }
}

function mouseDragged() {
    if (!gameReadyToStart) return;
    if (gameState === 'SPLASH_SCREEN') return;

    if (gameState === 'PAUSED' || gameState === 'SHOP' || gameState === 'WELCOME_SCREEN' || gameState === 'MENU' || gameState === 'GAME_OVER') {
        return;
    }
    if (gameState === 'ACHIEVEMENTS_SCREEN') {
        scrollOffsetAchievements -= (mouseY - pmouseY) / scaleFactor * 0.5;
        // Ограничиваем скролл, чтобы он не выходил за границы
        scrollOffsetAchievements = constrain(scrollOffsetAchievements, 0, maxScrollOffsetAchievements); 
        return false; 
    }

    if (draggingBamboo) {
        dragX = mouseX; 
        dragY = mouseY; 
    }
    else if (draggingApple) {
        dragX = mouseX; 
        dragY = mouseY; 
    }
}

function mouseReleased() {
    if (!gameReadyToStart) return;
    if (gameState === 'SPLASH_SCREEN') return;

    if (gameState === 'PAUSED' || gameState === 'SHOP' || gameState === 'WELCOME_SCREEN' || gameState === 'MENU' || gameState === 'ACHIEVEMENTS_SCREEN' || gameState === 'GAME_OVER') {
        return;
    }
    if (draggingBamboo) {
        draggingBamboo = false;

        let ryzhikX = width / 2 / scaleFactor; 
        let ryzhikY = height / 2 / scaleFactor + 10 + 40; 
        let ryzhikW = 128;
        let ryzhikH = 128;

        let dropX = dragX / scaleFactor; 
        let dropY = dragY / scaleFactor; 

        if (
            dropX > ryzhikX - ryzhikW / 2 &&
            dropX < ryzhikX + ryzhikW / 2 &&
            dropY > ryzhikY - ryzhikH / 2 && 
            dropY < ryzhikY + ryzhikH / 2  
        ) {
            if (collectedBamboo > 0) {
                if (lives === 1 && !fedOnLowHealthAchieved) { 
                    fedOnLowHealthAchieved = true;
                }
                collectedBamboo--; 
                if (lives < maxLives) {
                    lives++;
                }
                if (isMusicOn && eatSound) {
                    eatSound.play();
                }
                feeding = true;
                feedingStartTime = millis();
                firstFeedAchieved = true; 
                console.log("Рыжик накормлен бамбуком! Жизней: " + lives);
                saveGameData(true);
            } else {
                console.log(getTranslation('no_bamboo_in_inventory'));
            }
        }
    }
    else if (draggingApple) {
        draggingApple = false;

        let ryzhikX = width / 2 / scaleFactor; 
        let ryzhikY = height / 2 / scaleFactor + 10 + 40; 
        let ryzhikW = 128;
        let ryzhikH = 128;

        let dropX = dragX / scaleFactor; 
        let dropY = dragY / scaleFactor; 

        if (
            dropX > ryzhikX - ryzhikW / 2 &&
            dropX < ryzhikX + ryzhikW / 2 &&
            dropY > ryzhikY - ryzhikH / 2 && 
            dropY < ryzhikY + ryzhikH / 2  
        ) {
            if (collectedApple > 0) {
                if (lives === 1 && !fedOnLowHealthAchieved) { 
                    fedOnLowHealthAchieved = true;
                }
                collectedApple--; 
                lives = constrain(lives + 2, 0, maxLives); // 🍎 яблоко теперь даёт 2 жизни
                if (isMusicOn && eatSound) {
                    eatSound.play(); 
                }
                feeding = true;
                feedingStartTime = millis();
                firstFeedAchieved = true; 
                console.log("Рыжик съел яблоко! Жизней: " + lives);
                saveGameData(true);
            } else {
                console.log(getTranslation('no_apples_in_inventory'));
            }
        }
    }
    checkAchievements(); 
}

function mouseWheel(event) {
    if (!gameReadyToStart) return;
    if (gameState === 'SPLASH_SCREEN') return;

    if (gameState === 'ACHIEVEMENTS_SCREEN') {
        let scrollAmount = event.deltaY * 0.5; 
        scrollOffsetAchievements += scrollAmount;
        // Ограничиваем скролл, чтобы он не выходил за границы
        scrollOffsetAchievements = constrain(scrollOffsetAchievements, 0, maxScrollOffsetAchievements); 
        return false; 
    }
    return true; 
}

function spawnApple() {
    let targetDisplayWidth = width / scaleFactor; 
    apples.push({
        x: random(30, targetDisplayWidth - 30),
        y: -20
    });
    console.log("Яблоко упало! (Всего кликов: " + totalClickCount + ")");
}

function keyPressed() {
    // Эта функция пока не используется
}

// Убрал параметр forceFullReset из resetGame(), так как полный сброс делается только через dev-консоль SDK
// Обычный resetGame() должен сбрасывать только текущую игровую сессию.
function resetGame() {
    clickCount = 0;
    collectedBamboo = 0;
    lives = 3;
    hearts = [];
    bamboos = [];

    collectedApple = 0;
    apples = [];
    draggingApple = false;

    currentBaseBambooSpeed = INITIAL_BAMBOO_FALL_SPEED;
    speedIncreaseCounter = 0;
    
    inventoryOpen = false;
    draggingBamboo = false;
    motivatorActive = false;
    lifeLossPending = false;
    yawnStage = 0;
    feeding = false;
    currentImage = ryzhikIdle;

    let now = millis();
    lastInteractionTime = now; 
    lastYawnTime = now;
    lastHealthLossTime = now;
    elapsedPauseTime = 0;

    // Эти переменные должны восстанавливаться из сохранения, а не сбрасываться здесь,
    // если только не был произведен полный сброс через механизм SDK
    // maxLivesUpgradesCount = 0; 
    // toyUpgradesCount = 0;      
    activeExtraHearts = []; // Сбрасываем активные сердца текущей сессии
    toyBoostActive = false;
    motivatorThreshold = 30000;
    musicStarted = false; // Сбрасываем, чтобы музыка начала играть снова при PLAYING

    bambooSlowdownActive = false;
    bambooSlowdownStartTime = 0;

    gameState = 'WELCOME_SCREEN'; // Переходим на начальный экран
    
    lifeLostDuringGame = false; // Этот флаг сбрасывается, так как он относится к текущей игровой сессии для достижения "Долгожитель"

    // Достижения и totalClickCount не сбрасываются здесь, они управляются сохранением/загрузкой.
    console.log("Game state reset for new session.");
}
